
package pertemuan.pkg12;

/**
 *
 * @author LAB F
 */
public class Pertemuan12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
